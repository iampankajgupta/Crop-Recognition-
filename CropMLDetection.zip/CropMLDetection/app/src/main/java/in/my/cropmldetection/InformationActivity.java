package in.my.cropmldetection;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Environment;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class InformationActivity extends AppCompatActivity {
    TextView name,description;

    public static final String fileName = "Example.pdf";

    String cropName;

    Button getMarketPrice,cropLocation;
    FloatingActionButton ShareBtn;
    ImageView cropImage ;

    byte[] byteArray;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_information);
        name = findViewById(R.id.cropName);
        description = findViewById(R.id.cropDescription);


        ShareBtn = findViewById(R.id.ShareBtn);
        getMarketPrice = findViewById(R.id.getPriceInfo);

        cropImage = findViewById(R.id.cropImage);


//        Bitmap bitmap = (Bitmap) getIntent().getParcelableExtra("cropImage");
//
//        cropImage.setImageBitmap(bitmap);


//        int bytes = bitmap.getByteCount();
//
//        ByteBuffer byteBuffer = ByteBuffer.allocate(bytes);
//
//        bitmap.copyPixelsFromBuffer(byteBuffer);
//
//        byte [] bytesArray = byteBuffer.array();
//
//


//        CURSOR IS FOR RETRIVING DATA FROM DATABASE
//         IT HAS TWO METHOD MOVE TO FIRST AND MOVE TO NEXT '

//        CONTENT VALUES ARE USED TO PUT DATA INTO DATABASE
//
        cropName = getIntent().getStringExtra("clickedCrop");

        DatabaseHelper helper = new DatabaseHelper(this);
        SQLiteDatabase database = helper.getReadableDatabase();
        String query = "SELECT NAME,DESCRIPTION FROM CROPINFO WHERE NAME=?";


// IN THE NEW STRING BRACKETS THE REAL TIME CROP VALUE IS PASSED

        Cursor cursor = database.rawQuery(query,new String[]{cropName});

        if(cursor !=null){
            cursor.moveToFirst();
        }
//        THE CROP NAME AND CROP DESCRIPTION IS RETRIVED

        String nameTxt = cursor.getString(0);
        String descriptionTxt = cursor.getString(1);

        name.setText(nameTxt);
        description.setText(descriptionTxt);

        String combine = nameTxt+"\n\n"+descriptionTxt;

        getMarketPrice = findViewById(R.id.getPriceInfo);
        cropLocation = findViewById(R.id.cropLocation);


//        Drawable drawable = this.getResources().getDrawable(R.drawable.bg);
//        Bitmap bitmap = ((BitmapDrawable)drawable).getBitmap();
//
//
//        ByteBuffer byteBuffer = ByteBuffer.allocate(bitmap.getByteCount());
//        bitmap.copyPixelsFromBuffer(byteBuffer);
//        byte[] bytes = new byte[byteBuffer.remaining()];


        cropLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(InformationActivity.this,ShowCropLocationActivity.class);
                intent1.putExtra("cropName",cropName);
                startActivity(intent1);

            }
        });

        ShareBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Document document = new Document();
                String fileName = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(System.currentTimeMillis());

                String mFilePath = Environment.getExternalStorageDirectory() + "/" + fileName + ".pdf";

                try{
                    PdfWriter.getInstance(document,new FileOutputStream(mFilePath));
                    document.open();

//                    IMAGE ADDING TO PDF FILE IS PENDING

//                    Image image = Image.getInstance(bytesArray);
//                    image.setAlignment(Image.ALIGN_TOP);
//                    document.add(image);


                    document.add(new Paragraph(combine));
                    document.close();

                    Intent intent1 = new Intent(Intent.ACTION_SEND);
                    intent1.setType("application/pdf");
                    startActivity(intent1);

                    Toast.makeText(InformationActivity.this, "File save Successfuly", Toast.LENGTH_SHORT).show();
//                    Log.d("msg",fileName+".pdf");
                }catch (Exception e){
                    Log.d("msg",e.getMessage());
                }
            }
        });

        getMarketPrice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                getData();

            }
        });
    }
}
