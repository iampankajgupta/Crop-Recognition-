package in.my.cropmldetection;

public class CropData {
}
