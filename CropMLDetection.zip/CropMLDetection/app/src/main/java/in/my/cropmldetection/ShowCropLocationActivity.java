package in.my.cropmldetection;

import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.util.Log;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;
public class ShowCropLocationActivity extends FragmentActivity implements OnMapReadyCallback {
    private GoogleMap mMap;
    String cropName;
    ArrayList<LatLng> WheatLocations = new ArrayList<>();
    ArrayList<LatLng> riceLocations = new ArrayList<>();
    ArrayList<LatLng> jowarLocations = new ArrayList<LatLng>();
    ArrayList<LatLng> bajraLocations = new ArrayList<>();


//    HashMap<String,LatLng> WheatLocation = new HashMap<>();


    LatLng UttarPradesh = new LatLng(26.8467, 80.9462);
    LatLng Punjab = new LatLng(31.1471, 75.3412);
    LatLng Haryana = new LatLng(29.0588, 76.0856 );
    LatLng MadhyaPradesh = new LatLng(22.9734, 78.6569);
    LatLng Rajasthan = new LatLng(27.0238, 74.2179);
    LatLng Bihar = new LatLng(25.0961, 85.3131);
    LatLng Gujrat = new LatLng(22.2587, 71.1924);
    LatLng TamilNadu = new LatLng(11.1271, 78.6569);
    LatLng Chhattisgarh = new LatLng(21.2787, 81.8661);
    LatLng Odisha = new LatLng(20.9517, 85.0985);
    LatLng Assam = new LatLng(26.2006, 92.9376);
    LatLng Karnataka = new LatLng(15.3173, 75.7139);
    LatLng Maharashtra = new LatLng(19.7515, 75.7139);
    LatLng ArunachalPradesh = new LatLng(28.2180, 94.7278);



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_crop_location);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        cropName = getIntent().getStringExtra("cropName");

        Log.d("cropName",cropName);


//        IF THE CROP NAME IS WHEAT THEN CALL WHEAT LOCATION METHOD TO ALL LOCATIONS OF WHEAT IN WHEATlOCATIOND ARRAY LIST

        if (cropName.equals("Wheat")){
            wheatLocations();
        }
        if (cropName.equals("Rice")){
            riceLocations();
        }
        if (cropName.equals("Jowar")){
            jowarLocations();
        }
        if (cropName.equals("Bajra")){
            bajraLocations();
        }
    }

    private void jowarLocations() {
        jowarLocations.add(Maharashtra);
        jowarLocations.add(ArunachalPradesh);
        jowarLocations.add(UttarPradesh);
        jowarLocations.add(Rajasthan);
        jowarLocations.add(Gujrat);
        jowarLocations.add(MadhyaPradesh);
        jowarLocations.add(Karnataka);
    }

    private void bajraLocations(){
        bajraLocations.add(Maharashtra);
        bajraLocations.add(Haryana);
        bajraLocations.add(Gujrat);
        bajraLocations.add(UttarPradesh);

    }
    public void wheatLocations(){
        WheatLocations.add(UttarPradesh);
        WheatLocations.add(Punjab);
        WheatLocations.add(Haryana);
        WheatLocations.add(MadhyaPradesh);
        WheatLocations.add(Rajasthan);
        WheatLocations.add(Bihar);
        WheatLocations.add(Gujrat);


//        WheatLocation.put("UttarPradesh",UttarPradesh);
//        WheatLocation.put("Punjab",Punjab);
//        WheatLocation.put("Haryana",Haryana);
//        WheatLocation.put("MadhyaPradesh",MadhyaPradesh);
//        WheatLocation.put("Bihar)",Bihar);
//        WheatLocation.put("Rajasthan",Rajasthan);
//        WheatLocation.put("Gujrat",Gujrat);

    }
    public void riceLocations(){
        riceLocations.add(Bihar);
        riceLocations.add(Punjab);
        riceLocations.add(Odisha);
        riceLocations.add(Karnataka);
        riceLocations.add(Assam);
        riceLocations.add(TamilNadu);
        riceLocations.add(Chhattisgarh);
    }
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

//         markers titie is missing



        if (cropName.equals("Wheat")){
            for(int i = 0;i<WheatLocations.size();i++){
                mMap.addMarker(new MarkerOptions().position(WheatLocations.get(i)).title("Marker"));
                mMap.animateCamera(CameraUpdateFactory.zoomTo(15.0f));
                mMap.moveCamera(CameraUpdateFactory.newLatLng(WheatLocations.get(i)));
            }
        }
        if (cropName.equals("Rice")){
            for(int i = 0;i<riceLocations.size();i++){
                mMap.addMarker(new MarkerOptions().position(riceLocations.get(i)).title("Marker"));
                mMap.animateCamera(CameraUpdateFactory.zoomTo(15.0f));
                mMap.moveCamera(CameraUpdateFactory.newLatLng(riceLocations.get(i)));
            }
        }
        if (cropName.equals("Jowar")){
            for(int i = 0;i<jowarLocations.size();i++){
                mMap.addMarker(new MarkerOptions().position(jowarLocations.get(i)).title("Marker"));
                mMap.animateCamera(CameraUpdateFactory.zoomTo(20.0f));
                mMap.moveCamera(CameraUpdateFactory.newLatLng(jowarLocations.get(i)));
            }
        }
        if (cropName.equals("Bajra")){
            for(int i = 0;i<bajraLocations.size();i++){
                mMap.addMarker(new MarkerOptions().position(bajraLocations.get(i)).title("Marker"));
                mMap.animateCamera(CameraUpdateFactory.zoomTo(16.0f));
                mMap.moveCamera(CameraUpdateFactory.newLatLng(bajraLocations.get(i)));


            }
        }



        // Add a marker in Sydney, Australia, and move the camera.
//        LatLng sydney = new LatLng(29.0588, 76.0856);
//        mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
//        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
    }
}
