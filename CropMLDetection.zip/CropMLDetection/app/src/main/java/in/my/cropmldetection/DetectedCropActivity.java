package in.my.cropmldetection;

import android.content.Intent;
import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class DetectedCropActivity extends AppCompatActivity {
    ListView listView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detected_crop);
        listView = findViewById(R.id.listView);

        Bitmap bitmap = (Bitmap) getIntent().getParcelableExtra("BitmapImage");

        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("Wheat");
        arrayList.add("Jowar");
        arrayList.add("Bajra");
        arrayList.add("Rice");
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,arrayList);

//                new ArrayAdapter(this,android.R.layout.simple_list_item_1,arrayList);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                language conversion is pending here i.e convert int clicktext to String and manage things

                String clicktext = arrayList.get(position);
                Intent intent1 = new Intent(DetectedCropActivity.this,InformationActivity.class);
                intent1.putExtra("clickedCrop",clicktext);
                intent1.putExtra("cropImage",bitmap);

                startActivity(intent1);
            }
        });
    }
}
