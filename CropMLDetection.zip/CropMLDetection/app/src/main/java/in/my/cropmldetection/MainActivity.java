package in.my.cropmldetection;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;

import android.content.res.Configuration;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

//import org.tensorflow.lite.Interpreter;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    Button chooselanguage,goToHomeActivity;
    AlertDialog.Builder builder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        loadLocale();
        setContentView(R.layout.activity_main);
        chooselanguage = findViewById(R.id.chooseLanguage);
        goToHomeActivity = findViewById(R.id.goToHomeActivity);

//        change action bar title , if you

        chooselanguage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                showChangeLanguageDialog();
            }
        });

        goToHomeActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                startActivity(intent);
            }
        });
    }
    private void showChangeLanguageDialog() {

        final String[] listItems = {"English","हिंदी","தமிழ்","తెలుగు"};

        builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Choose Langaueg...");
        builder.setSingleChoiceItems(listItems, -1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int i) {

                if (i==0){
//                     EMGLISH

                    setLocale("");
                    recreate();

                }
                if (i==1){
//                     HINDI
                    setLocale("hi");
                    recreate();

                }
                if (i==2){
//                    TAMIL
                    setLocale("ta");
                    recreate();

                }
                if (i==3){

//                     TELUGU

                    setLocale("te");
                    recreate();

                }

                dialog.dismiss();

            }
        });
        AlertDialog mDialog = builder.create();

        mDialog.show();
    }

    public void setLocale(String language){
        Locale locale = new Locale(language);
        Locale.setDefault(locale);
        Configuration config = new Configuration();

        config.locale = locale;
        getBaseContext().getResources().updateConfiguration(config,getBaseContext().getResources().getDisplayMetrics());

// save data to shared preferences

        SharedPreferences.Editor editor = getSharedPreferences("Settings",MODE_PRIVATE).edit();
        editor.putString("My_Lang",language);
        editor.apply();

    }
//    load language saved in shared preferences

    public void loadLocale(){
        SharedPreferences prefs = getSharedPreferences("Settings",MODE_PRIVATE);

        String language = prefs.getString("My_Lang","");
        setLocale(language);
    }


}
